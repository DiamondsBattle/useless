# useless
useless is my personal python library, packed with boring but usefull stuff
