from useless.stack import Stack
from useless.globals import *