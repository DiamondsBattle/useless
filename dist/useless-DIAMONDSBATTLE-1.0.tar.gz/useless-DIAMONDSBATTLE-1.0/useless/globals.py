color_codes = {'success': '\u001b[92m',
               'warning': '\u001b[93m',
               'error': '\u001b[91m',
               'reset': '\u001b[0m'}